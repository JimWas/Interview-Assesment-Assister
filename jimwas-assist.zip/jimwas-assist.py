import google.generativeai as genai
import pyautogui
import time
from PIL import Image

# Configure Gemini
genai.configure(api_key="AIzaSyCaq-86OntcfGGEEw3DbTG6p2fOp2LlP5U")  # or use os.environ["GEMINI_API_KEY"]

model = genai.GenerativeModel("gemini-1.5-flash")  # or gemini-1.5-pro
time.sleep(10)  # wait 10 seconds

while True:
    # Take screenshot
    screenshot = pyautogui.screenshot()
    screenshot.save("screenshot.png")

    # Open image
    img = Image.open("screenshot.png")

    # Send to Gemini
    response = model.generate_content([
        "Please answer the question in the browser window in this screenshot.",
        img
    ])

    print("Gemini:", response.text)

    time.sleep(120)  # wait 2 minutes
